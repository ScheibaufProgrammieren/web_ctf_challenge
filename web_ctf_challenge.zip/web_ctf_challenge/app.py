from flask import Flask, request, redirect, session, render_template_string

app = Flask(__name__)
app.secret_key = "supersecretkey"

users = {
    "admin@fsec.local": {"password": "admin123", "role": "admin"},
    "joe@fsec.local": {"password": "joejoe", "role": "user"},
    "player@fsec.local": {"password": "ctfplayer", "role": "user"},
}


@app.route("/welcome")
def welcome():
    welcome_page = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>FSEC CTF Challenge</title>
        <style>
            body {
                margin: 0;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(to right, #4facfe, #00f2fe);
                color: #222;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }

            .card {
                background: white;
                border-radius: 16px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                padding: 40px;
                max-width: 600px;
                width: 90%;
                text-align: center;
                animation: fadeIn 1s ease-in-out;
            }

            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }

            h1 {
                font-size: 2.5em;
                color: #007BFF;
                margin-bottom: 20px;
            }

            .emoji {
                font-size: 2em;
                margin-bottom: 10px;
            }

            p {
                font-size: 1.1em;
                margin-bottom: 30px;
                line-height: 1.6;
            }

            .objective {
                background: #f1f1f1;
                border-left: 6px solid #007BFF;
                padding: 15px;
                margin-bottom: 30px;
                text-align: left;
                font-weight: bold;
                font-size: 1em;
            }

            .start-btn {
                background-color: #007BFF;
                color: white;
                padding: 15px 25px;
                border: none;
                border-radius: 8px;
                font-size: 1.1em;
                text-decoration: none;
                cursor: pointer;
                transition: background-color 0.3s ease;
            }

            .start-btn:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="emoji">🚩</div>
            <h1>FSEC Web CTF Challenge</h1>
            <p>
                Welcome, agent! You’ve entered the FSEC Web CTF arena where wit beats code. This challenge tests your web hacking skills — can you rise to the top?
            </p>
            <div class="objective">
                🎯 <strong>Your Objective:</strong><br>
                Bypass login, gain admin access, and delete the user <strong>joe</strong>.
            </div>
            <a href="/login" class="start-btn">Start the Challenge</a>
        </div>
    </body>
    </html>
    """
    return render_template_string(welcome_page)




login_page = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CTF Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #43e97b, #38f9d7);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .login-card {
            background: #fff;
            padding: 40px 30px;
            border-radius: 16px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 420px;
            animation: fadeIn 0.6s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            margin-bottom: 25px;
            text-align: center;
            font-size: 1.9em;
            color: #28a745;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1em;
            transition: border-color 0.3s;
        }

        input:focus {
            border-color: #28a745;
            outline: none;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #28a745;
            color: white;
            font-size: 1em;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
            margin-top: 10px;
        }

        button:hover {
            background: #218838;
        }

        .error {
            color: #dc3545;
            text-align: center;
            margin-top: 15px;
        }

        .tips {
            background: #f1f1f1;
            padding: 15px;
            border-left: 5px solid #28a745;
            margin-top: 25px;
            font-size: 0.95em;
            border-radius: 8px;
        }

        .tips strong {
            display: block;
            margin-bottom: 8px;
        }

        .footer-text {
            margin-top: 30px;
            font-size: 0.8em;
            color: #777;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h2>🛡️ CTF Login</h2>
        <form action="/login" method="post">
            <input name="email" type="text" placeholder="Email" required>
            <input name="password" type="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        {% if error %}
            <div class="error">{{ error }}</div>
        {% endif %}
        <div class="tips">
            <strong>💡 Hints & Warnings:</strong>
            - No password recovery... it's CTF, not customer support.<br>
            - Who needs a register page anyway?<br>
            - Definitely no secrets in the URL paths 👀<br>
            - Our dev says: “Obscurity = Security.” Seems legit.
        </div>
        <div class="footer-text">
            Good luck. You'll need it. 🕵️‍♂️
        </div>
    </div>
</body>
</html>
"""


register_page = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>🔐 Not a Registration Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #fceabb, #f8b500);
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .register-card {
            background-color: #fff8e1;
            padding: 40px 30px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            width: 100%;
            max-width: 420px;
            animation: fadeIn 0.6s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            margin-bottom: 20px;
            text-align: center;
            color: #d39e00;
            font-size: 1.8em;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1em;
            transition: border 0.3s ease;
        }

        input:focus {
            border-color: #ffc107;
            outline: none;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #ffc107;
            color: #212529;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background: #e0a800;
        }

        .warning {
            background: #fff3cd;
            border-left: 5px solid #856404;
            padding: 12px;
            margin-top: 25px;
            font-size: 0.95em;
            color: #856404;
            border-radius: 8px;
        }

        .footer-text {
            text-align: center;
            font-size: 0.8em;
            color: #999;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="register-card">
        <h2>🚫 Definitely Not a Register Page</h2>
        <form method="post">
            <input name="email" type="text" placeholder="Email Address" required>
            <input name="password" type="password" placeholder="Super Secret Password" required>
            <button type="submit">Register</button>
        </form>
        <div class="warning">
            ⚠️ Whoa! You weren't supposed to find this. <br>
            Either you're a dev, a bug hunter, or just *way too curious*.<br>
            Proceed with caution — you might discover something... unintended.
        </div>
        <div class="footer-text">
            This message will self-destruct in 3... 2... 💥
        </div>
    </div>
</body>
</html>
"""



@app.route("/", methods=["GET"])
def index():
    return redirect("/welcome")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        user = users.get(email)
        if user and user["password"] == password:
            session["email"] = email
            return redirect("/dashboard")
        else:
            return render_template_string(login_page, error="Access Denied.")
    return render_template_string(login_page, error="")


@app.route("/signup", methods=["GET"])
def signup():
    return "403 Forbidden — Nothing to see here. Shoo. 🐱‍👤"

@app.route("/registeration", methods=["GET", "POST"])
def hidden_register():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        users[email] = {"password": password, "role": "user"}
        return redirect("/login")
    return render_template_string(register_page)


from flask import session, redirect, render_template_string

@app.route("/dashboard")
def dashboard():
    if "email" not in session:
        return redirect("/login")

    email = session["email"]
    role = users[email]["role"]
    username = email.split("@")[0]


    posts = [
        {"author": "joe@fsec.local", "content": "This is joe's post.", "image": None},
        {"author": "player@fsec.local", "content": "Welcome to the game!", "image": None},
        {"author": "admin@fsec.local", "content": "Admins rule the world.", "image": None},
        {"author": "red@fsec.local", "content": "Try harder. Think deeper.", "image": None},
        {"author": "blue@fsec.local", "content": "What if the profile isn't protected?", "image": None}
    ]
    username = email.split("@")[0]

    dashboard_html = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>🎮 CTF Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {
                margin: 0;
                font-family: 'Segoe UI', sans-serif;
                background: linear-gradient(to right, #ffecd2, #fcb69f);
            }
            .container {
                max-width: 960px;
                margin: 60px auto;
                padding: 40px 30px;
                background: #ffffff;
                border-radius: 20px;
                box-shadow: 0 8px 30px rgba(0,0,0,0.1);
            }
            h2 {
                text-align: center;
                color: #333;
                font-size: 2em;
                margin-bottom: 30px;
            }
            .nav {
                display: flex;
                justify-content: center;
                gap: 20px;
                margin-bottom: 35px;
            }
            .tab {
                padding: 10px 20px;
                border-radius: 12px;
                background: #fef1e6;
                color: #444;
                font-weight: 600;
                cursor: pointer;
                transition: 0.3s;
            }
            .tab:hover {
                background: #ffd8b8;
            }
            .post {
                display: flex;
                align-items: flex-start;
                gap: 15px;
                padding: 20px;
                margin-bottom: 20px;
                border-left: 5px solid #ffa94d;
                background: #fffaf4;
                border-radius: 12px;
                box-shadow: 0 3px 10px rgba(0,0,0,0.06);
            }
            .post img {
                width: 80px;
                height: 80px;
                border-radius: 10px;
                object-fit: cover;
                border: 2px solid #ffa94d;
            }
            .post .details {
                flex: 1;
            }
            .author {
                font-weight: bold;
                color: #c76c00;
                margin-bottom: 5px;
            }
            .content {
                color: #333;
            }
            .tip-bar {
                background-color: #fff3cd;
                padding: 12px 20px;
                border-left: 5px solid #ffc107;
                border-radius: 10px;
                cursor: pointer;
                font-weight: bold;
                margin-bottom: 10px;
                color: #856404;
                transition: background 0.3s ease;
            }
            .tip-bar:hover {
                background-color: #ffe69c;
            }
            .tips {
                display: none;
                background: #fffbea;
                border-radius: 10px;
                padding: 15px;
                margin-bottom: 25px;
                color: #5e4c0b;
                font-size: 0.95em;
            }
            .admin-badge {
                display: inline-block;
                background: #d4edda;
                color: #155724;
                padding: 4px 10px;
                border-radius: 8px;
                font-size: 0.8em;
                margin-left: 8px;
            }
        </style>
        <script>
            function toggleTips() {
                var tips = document.getElementById("tips");
                tips.style.display = tips.style.display === "block" ? "none" : "block";
            }
        </script>
    </head>
    <body>
        <div class="container">
            <h2>🔐 Welcome, {{ username }} {% if role == 'admin' %}<span class="admin-badge">Admin</span>{% endif %}</h2>

            <div class="tip-bar" onclick="toggleTips()">💡 Show CTF Tips</div>
            <div id="tips" class="tips">
                <ul>
                    <li>🔍 Change the profile URL — who are you really?</li>
                    <li>🧩 Admins can manage users... can you?</li>
                    <li>🧹 Try removing posts — or users — that shouldn't be removable.</li>
                    <li>🗝️ What else is hidden behind roles?</li>
                </ul>
            </div>

            <div class="nav">
                <div class="tab" onclick="window.location.href='/dashboard'">📄 Posts</div>
                <div class="tab" onclick="window.location.href='/profile/{{ email }}'">👤 Profile</div>
                {% if role == 'admin' %}
                <div class="tab" onclick="window.location.href='/manage'">🛠️ Manage Users</div>
                {% endif %}
            </div>

            {% for post in posts %}
            <div class="post">
                {% if post.image %}
                    <img src="{{ post.image }}" alt="Post Image">
                {% else %}
                    <img src="{{ url_for('static', filename='images/avatar2.png') }}" class="avatar">
                {% endif %}
                <div class="details">
                    <div class="author">✉️ {{ post.author }}</div>
                    <div class="content">📝 {{ post.content }}</div>
                </div>
            </div>
            {% endfor %}
        </div>
    </body>
    </html>
    """

    return render_template_string(dashboard_html, email=email, role=role, username=username, posts=posts)



    
@app.route("/profile/<email>")
def profile(email):
    if "email" not in session:
        return redirect("/login")

    current_user = session["email"]
    role = users[current_user]["role"]
    message = ""

    # Exploit path: visiting admin makes you admin
    if email == "admin@fsec.local" and role != "admin":
        session["email"] = "admin@fsec.local"
        current_user = "admin@fsec.local"
        role = "admin"
        message = "You feel powerful... 🕵️‍♂️ You have become the admin!"

    is_admin = role == "admin"
    target_user = users.get(email)  # ✅ define this BEFORE show_delete
    show_delete = is_admin and target_user and email != "admin@fsec.local"

    profile_html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Profile</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                background: linear-gradient(to right, #ffecd2, #fcb69f);
                margin: 0;
                padding: 0;
            }
            .container {
                max-width: 720px;
                margin: 60px auto;
                padding: 30px 40px;
                background: #fff;
                border-radius: 16px;
                box-shadow: 0 8px 24px rgba(0,0,0,0.08);
            }
            .nav {
                display: flex;
                justify-content: center;
                gap: 20px;
                margin-bottom: 30px;
            }
            .tab {
                font-weight: 600;
                cursor: pointer;
                color: #333;
                padding: 10px 20px;
                background: #fff0e6;
                border-radius: 12px;
                transition: background 0.3s ease;
            }
            .tab:hover {
                background-color: #ffd8b8;
            }
            h2 {
                text-align: center;
                color: #444;
                margin-bottom: 10px;
            }
            .avatar {
                width: 100px;
                height: 100px;
                border-radius: 50%;
                object-fit: cover;
                border: 3px solid #ffa94d;
                display: block;
                margin: 0 auto 15px;
            }
            .role-badge {
                text-align: center;
                font-weight: bold;
                background-color: #e0f7fa;
                color: #006064;
                padding: 6px 12px;
                border-radius: 10px;
                display: inline-block;
                margin: 10px auto 25px;
            }
            .message {
                background: #e6ffe6;
                border: 1px solid #b3ffb3;
                padding: 12px 18px;
                margin-bottom: 20px;
                border-radius: 10px;
                font-style: italic;
                color: #2d662d;
                text-align: center;
            }
            .delete-btn {
                background-color: #ff4d4d;
                color: white;
                padding: 12px 24px;
                border: none;
                border-radius: 10px;
                cursor: pointer;
                font-weight: bold;
                display: block;
                margin: 30px auto 0;
                box-shadow: 0 4px 12px rgba(255, 77, 77, 0.4);
                transition: background 0.3s;
            }
            .delete-btn:hover {
                background-color: #e63946;
            }
            .not-found {
                color: #777;
                text-align: center;
                margin-top: 40px;
                font-style: italic;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="nav">
                <div class="tab" onclick="window.location.href='/dashboard'">📄 Posts</div>
                <div class="tab" onclick="window.location.href='/profile/{{ current_user }}'">👤 Profile</div>
                {% if role == 'admin' %}
                <div class="tab" onclick="window.location.href='/manage'">🛠️ Manage Users</div>
                {% endif %}
            </div>

            <img src="{{ url_for('static', filename='images/avatar.webp') }}" class="avatar">


            <h2>{{ email }}</h2>
            <div class="role-badge">Role: {{ role|capitalize }}</div>

            {% if message %}
            <div class="message">{{ message }}</div>
            {% endif %}

        </div>
    </body>
    </html>
    """
    return render_template_string(
        profile_html,
        email=email,
        role=role,
        current_user=current_user,
        message=message,
        show_delete=show_delete,
        target_user=target_user
    )

    
@app.route("/delete/<email>", methods=["POST"])
def delete_user(email):
    if "email" not in session:
        return redirect("/login")

    current_user = session["email"]
    if current_user != "admin@fsec.local" or email not in users:
        return "Unauthorized", 403

    if email == "joe@fsec.local":
        del users[email]
        return render_template_string("""
        <html>
        <head>
            <title>🎉 Congratulations!</title>
            <style>
                body {
                    font-family: 'Segoe UI', sans-serif;
                    background: linear-gradient(to right, #4facfe, #00f2fe);
                    text-align: center;
                    padding: 100px;
                    color: white;
                }
                h1 {
                    font-size: 3em;
                    margin-bottom: 20px;
                }
                .flag {
                    font-size: 1.5em;
                    background: rgba(0,0,0,0.1);
                    padding: 15px;
                    border-radius: 10px;
                    display: inline-block;
                    margin-top: 20px;
                }
            </style>
        </head>
        <body>
            <h1>🎉 You did it!</h1>
            <p>Joe has been deleted from existence. The system is now yours.</p>
            <div class="flag">🏁 Flag: FSEC{admin_p0wers_gr4nt3d}</div>
        </body>
        </html>
        """)
    elif email != "admin@fsec.local":
        del users[email]
        return redirect("/manage")

    return "Cannot delete admin!", 403

    

@app.route("/manage")
def manage_users():
    if "email" not in session or session["email"] != "admin@fsec.local":
        return redirect("/dashboard")

    user_list = [email for email in users if email not in ["admin@fsec.local"]]
    return render_template_string("""
    <html>
    <head>
        <title>Manage Users</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                background: linear-gradient(to right, #ffecd2, #fcb69f);
                margin: 0;
                padding: 0;
            }
            .container {
                max-width: 700px;
                margin: auto;
                padding: 40px;
                background: white;
                border-radius: 15px;
                box-shadow: 0 0 12px rgba(0,0,0,0.1);
                margin-top: 60px;
            }
            .user-entry {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid #eee;
                padding: 10px 0;
            }
            .delete-btn {
                background-color: #dc3545;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 5px 15px;
                cursor: pointer;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>🛠️ Manage Users</h2>
            {% for user in users %}
                <div class="user-entry">
                    <div>{{ user }}</div>
                    <form method="POST" action="/delete/{{ user }}">
                        <button class="delete-btn">Delete</button>
                    </form>
                </div>
            {% endfor %}
        </div>
    </body>
    </html>
    """, users=user_list)




if __name__ == "__main__":
    app.run(debug=True)
